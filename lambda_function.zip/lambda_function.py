def lambda_handler(event,context):
    return {
        "statuscode": 200,
        "message": "Hello from lambda!"
    }